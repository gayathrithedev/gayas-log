import { useEffect, useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import { profile, socials } from "../data/content";
import { Button, Frame, Sticker } from "../components/primitives";
import { Mug, Braces, Atom, Sticky, Cursor, Spark } from "../components/Doodles";

/* Doodles live in the empty margins beside the column — only where there's room. */
const OBJECTS = [
  { C: Braces, cls: "left-[6%] top-[24%] h-11 w-11 text-ink70",   r: -8,  d: 0,   depth: 30 },
  { C: Mug,    cls: "right-[7%] top-[18%] h-12 w-12 text-ink40",  r: 10,  d: 0.6, depth: -24 },
  { C: Atom,   cls: "right-[9%] top-[58%] h-14 w-14 text-ink70",  r: -6,  d: 1.2, depth: 38 },
  { C: Sticky, cls: "left-[9%] top-[62%] h-11 w-11 text-ink40",   r: 7,   d: 0.9, depth: -18 },
  { C: Cursor, cls: "left-[13%] top-[12%] h-8 w-8 text-ink40",    r: -14, d: 1.6, depth: 20 },
  { C: Spark,  cls: "right-[14%] top-[38%] h-7 w-7 text-ink40",   r: 4,   d: 2.1, depth: -26 },
];

export default function Hero() {
  const reduce = useReducedMotion();
  const [pointer, setPointer] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (reduce || window.matchMedia("(pointer: coarse)").matches) return;
    const onMove = (e) =>
      setPointer({
        x: e.clientX / window.innerWidth - 0.5,
        y: e.clientY / window.innerHeight - 0.5,
      });
    window.addEventListener("pointermove", onMove);
    return () => window.removeEventListener("pointermove", onMove);
  }, [reduce]);

  const rise = (delay) => ({
    initial: reduce ? false : { opacity: 0, y: 16 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] },
  });

  return (
    <section id="top" className="relative pt-24 sm:pt-28">
      <div aria-hidden className="pointer-events-none absolute inset-0 hidden xl:block">
        {OBJECTS.map(({ C, cls, r, d, depth }, i) => (
          <motion.div
            key={i}
            className={`absolute ${cls} animate-floaty opacity-40`}
            style={{ "--r": `${r}deg`, animationDelay: `${d}s` }}
            animate={{ x: pointer.x * depth, y: pointer.y * depth }}
            transition={{ type: "spring", stiffness: 40, damping: 18, mass: 1.2 }}
          >
            <C className="h-full w-full" />
          </motion.div>
        ))}
      </div>

      <div className="shell relative">
        {/* portrait */}
        <motion.div {...rise(0)}>
          <Frame
            src={profile.portrait}
            alt={`${profile.name}, portrait`}
            label="portrait"
            className="h-20 w-20 rounded-full border border-rule sm:h-24 sm:w-24"
          />
        </motion.div>

        {/* greeting + name */}
        <motion.div {...rise(0.08)} className="mt-6 flex flex-wrap items-center gap-x-3 gap-y-2">
          <span className="greeting text-xl">{profile.greeting}</span>
          <span className="eyebrow">{profile.greetingRoman} — hello</span>
          {profile.available && (
            <Sticker tone="paper2" rotate={-1.5}>
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-ink40 opacity-60" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-ink" />
              </span>
              {profile.availableNote}
            </Sticker>
          )}
        </motion.div>

        <motion.h1
          {...rise(0.14)}
          className="mt-4 font-display text-[38px] leading-[1.08] tracking-[-0.02em] text-balance sm:text-[46px]"
        >
          {profile.name}
        </motion.h1>

        <motion.p {...rise(0.2)} className="mt-2 text-[15px] text-ink40">
          {profile.role} · {profile.location}
        </motion.p>

        {/* intro */}
        <motion.p {...rise(0.26)} className="mt-7 text-pretty text-[17px] leading-[1.7] text-ink70">
          {profile.headline.map((chunk, i) => (
            <span key={i} className={chunk.em ? "italic text-ink" : ""}>
              {chunk.text}
            </span>
          ))}
        </motion.p>

        <motion.p {...rise(0.32)} className="mt-4 text-pretty text-[17px] leading-[1.7] text-ink70">
          {profile.blurb}
        </motion.p>

        {/* actions */}
        <motion.div {...rise(0.38)} className="mt-8 flex flex-wrap items-center gap-3">
          <Button href="#work">See the work</Button>
          <Button href={`mailto:${profile.email}`} tone="ghost">Get in touch</Button>
        </motion.div>

        {/* socials */}
        <motion.ul {...rise(0.44)} className="mt-8 flex flex-wrap items-center gap-x-5 gap-y-2">
          {socials.map((s) => (
            <li key={s.label}>
              <a
                href={s.href}
                target="_blank"
                rel="noreferrer noopener"
                className="link-swipe font-mono text-[12px] text-ink40 transition-colors hover:text-ink"
              >
                {s.label} ↗
              </a>
            </li>
          ))}
        </motion.ul>
      </div>
    </section>
  );
}
