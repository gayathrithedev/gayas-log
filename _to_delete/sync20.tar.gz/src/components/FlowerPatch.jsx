import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { HazelWalking, HazelSleeping, CatBed } from "./Hazel";
import { setCatCursorHidden } from "../lib/catCursorStore";

/* Hover the meadow once and the whole thing plays out: five colour flowers
   drop in from above, Hazel walks in from the right edge of the screen, a
   bed appears, she curls up. After that she stays — hovering her makes her
   purr and peek. */

const PETALS = 11;

function Daisy({ cx, cy, r, rot = 0, color }) {
  return (
    <g stroke={color} fill="none" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round">
      {Array.from({ length: PETALS }, (_, i) => {
        const a = (360 / PETALS) * i + rot;
        return (
          <ellipse
            key={i}
            cx={cx}
            cy={cy - r * 0.62}
            rx={r * 0.19}
            ry={r * 0.42}
            transform={`rotate(${a} ${cx} ${cy})`}
          />
        );
      })}
      <circle cx={cx} cy={cy} r={r * 0.2} />
    </g>
  );
}

function Stem({ x, yTop, yBase, sway = 4, color }) {
  const h = yBase - yTop;
  const d = `M ${x} ${yBase}
             C ${x - sway} ${yBase - h * 0.3}, ${x + sway} ${yBase - h * 0.5}, ${x - sway * 0.4} ${yBase - h * 0.72}
             S ${x} ${yTop + 2}, ${x} ${yTop}`;
  return <path d={d} stroke={color} fill="none" strokeWidth="1" strokeLinecap="round" />;
}

function Flower({ x, top, base, r, rot, sway, color }) {
  return (
    <>
      <Stem x={x} yTop={top + r * 0.9} yBase={base} sway={sway} color={color} />
      <Daisy cx={x} cy={top} r={r} rot={rot} color={color} />
    </>
  );
}

const INK = "#4E4E4B";
const BLUE = "#1D4ED8";
const YELLOW = "#E0A400";
const PINK = "#E0479B";

const BASE = [
  { x: 30, top: 60, base: 118, r: 11, rot: 6, sway: 4 },
  { x: 62, top: 34, base: 120, r: 16, rot: 14, sway: 5 },
  { x: 100, top: 42, base: 118, r: 14, rot: 3, sway: 4 },
  { x: 132, top: 66, base: 122, r: 12, rot: 20, sway: 3 },
];

const EXTRA = [
  { x: 14, top: 74, base: 120, r: 9, rot: 10, sway: 3, color: BLUE, delay: 0 },
  { x: 46, top: 84, base: 121, r: 8, rot: 24, sway: 3, color: PINK, delay: 0.14 },
  { x: 80, top: 70, base: 119, r: 10, rot: 2, sway: 4, color: YELLOW, delay: 0.07 },
  { x: 114, top: 88, base: 120, r: 8, rot: 16, sway: 3, color: BLUE, delay: 0.28 },
  { x: 148, top: 78, base: 121, r: 9, rot: 8, sway: 4, color: PINK, delay: 0.21 },
];

const EASE = [0.22, 1, 0.36, 1];
const WALK_MS = 2600;

export default function FlowerPatch({ className = "" }) {
  const reduce = useReducedMotion();
  const wrapRef = useRef(null);
  const timers = useRef([]);

  const [bloomed, setBloomed] = useState(false);
  const [phase, setPhase] = useState("idle"); // idle | walking | arrived
  const [walkFrom, setWalkFrom] = useState(0);
  const [petting, setPetting] = useState(false);
  const [peek, setPeek] = useState(false);

  const clear = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  };
  useEffect(() => clear, []);

  // once she's here, she stays — so this only ever runs the once
  const begin = () => {
    setCatCursorHidden(true);
    if (bloomed) return;
    setBloomed(true);

    if (reduce) {
      setPhase("arrived");
      return;
    }

    const rect = wrapRef.current?.getBoundingClientRect();
    // start off the right edge of the screen, relative to the patch
    setWalkFrom(rect ? window.innerWidth - rect.left + 60 : 700);

    timers.current.push(setTimeout(() => setPhase("walking"), 620));
    timers.current.push(setTimeout(() => setPhase("arrived"), 620 + WALK_MS));
  };

  const end = () => setCatCursorHidden(false);

  // hovering the sleeping cat: purr + a sleepy peek
  const pet = () => {
    if (phase !== "arrived") return;
    setPetting(true);
    clearTimeout(timers.current.peekTimer);
    setPeek(true);
    const t1 = setTimeout(() => setPeek(false), 900);
    const t2 = setTimeout(() => setPeek(true), 1500);
    const t3 = setTimeout(() => setPeek(false), 2200);
    timers.current.push(t1, t2, t3);
  };
  const unpet = () => {
    setPetting(false);
    setPeek(false);
  };

  return (
    <div
      ref={wrapRef}
      className={`relative ${className}`}
      onPointerEnter={begin}
      onPointerLeave={end}
    >
      <svg viewBox="0 0 162 130" role="img" aria-label="A small patch of daisies" className="h-full w-full overflow-visible">
        {BASE.map((f, i) => (
          <Flower key={`b${i}`} {...f} color={INK} />
        ))}

        {/* the colour flowers drop in from above */}
        {EXTRA.map((f, i) => (
          <motion.g
            key={`e${i}`}
            initial={false}
            animate={
              bloomed
                ? { opacity: 1, y: 0, scale: 1 }
                : { opacity: 0, y: -34, scale: 0.92 }
            }
            transition={{
              duration: reduce ? 0 : 0.9,
              delay: bloomed && !reduce ? f.delay : 0,
              ease: [0.16, 0.9, 0.28, 1.06],
            }}
          >
            <Flower {...f} />
          </motion.g>
        ))}
      </svg>

      {/* Hazel padding in from the right edge of the viewport */}
      <AnimatePresence>
        {phase === "walking" && (
          <motion.div
            className="pointer-events-none absolute bottom-[-10px] left-[86px] z-10"
            initial={{ x: walkFrom, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ opacity: 0, transition: { duration: 0.25 } }}
            transition={{
              x: { duration: WALK_MS / 1000, ease: "linear" },
              opacity: { duration: 0.35 },
            }}
          >
            <motion.div
              animate={{ y: [0, -2.5, 0] }}
              transition={{ duration: 0.34, repeat: Infinity, ease: "easeInOut" }}
            >
              <HazelWalking stride={1} className="h-[62px] w-[92px]" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* bed + sleeping cat, once she's arrived */}
      <AnimatePresence>
        {phase === "arrived" && (
          <motion.div
            className="absolute bottom-[-16px] left-[74px] z-10"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            onPointerEnter={pet}
            onPointerLeave={unpet}
          >
            {/* the bed pops in first */}
            <motion.div
              initial={reduce ? false : { scale: 0.4, opacity: 0, y: 8 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: [0.2, 1.4, 0.4, 1] }}
              className="relative"
            >
              <CatBed className="h-[42px] w-[120px]" />
              <Sparkles reduce={reduce} />

              {/* then she settles into it */}
              <motion.div
                className="absolute bottom-[13px] left-[10px]"
                initial={reduce ? false : { opacity: 0, y: -10, scale: 0.94 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.55, delay: reduce ? 0 : 0.45, ease: EASE }}
              >
                <motion.div
                  animate={reduce ? {} : { scaleY: [1, 1.03, 1] }}
                  transition={{ duration: petting ? 1.1 : 2.8, repeat: Infinity, ease: "easeInOut" }}
                  style={{ transformOrigin: "bottom center" }}
                >
                  <HazelSleeping peek={peek} earTwitch={petting} className="h-[48px] w-[84px]" />
                </motion.div>
                {petting && <Purr />}
              </motion.div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* A few motes when the bed appears. */
function Sparkles({ reduce }) {
  if (reduce) return null;
  const spots = [
    { x: 8, y: 2, d: 0 },
    { x: 52, y: -6, d: 0.12 },
    { x: 96, y: 0, d: 0.24 },
    { x: 112, y: 10, d: 0.34 },
  ];
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0">
      {spots.map((s, i) => (
        <motion.span
          key={i}
          className="absolute text-[10px] text-ochre"
          style={{ left: s.x, top: s.y }}
          initial={{ opacity: 0, scale: 0.4, y: 6 }}
          animate={{ opacity: [0, 1, 0], scale: [0.4, 1.1, 0.6], y: [6, -10, -18] }}
          transition={{ duration: 1.1, delay: 0.15 + s.d, ease: "easeOut" }}
        >
          ✦
        </motion.span>
      ))}
    </div>
  );
}

/* Purr arcs, while she's being petted. */
function Purr() {
  return (
    <svg viewBox="0 0 24 30" className="absolute -left-3 -top-2 h-[24px] w-[18px]" aria-hidden>
      {[0, 1, 2].map((i) => (
        <motion.path
          key={i}
          d={`M20 15 q -${5 + i * 4} -${5 + i * 3.5} 0 -${10 + i * 7}`}
          fill="none"
          stroke="#C56E23"
          strokeWidth="1.4"
          strokeLinecap="round"
          initial={{ opacity: 0, scale: 0.7 }}
          animate={{ opacity: [0, 0.85, 0], scale: [0.7, 1, 1.14] }}
          transition={{ duration: 1.3, repeat: Infinity, delay: i * 0.2, ease: "easeOut" }}
          style={{ transformBox: "fill-box", transformOrigin: "bottom right" }}
        />
      ))}
    </svg>
  );
}
