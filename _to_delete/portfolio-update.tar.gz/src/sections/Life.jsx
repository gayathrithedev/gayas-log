import { life } from "../data/content";
import { Reveal, SectionHead, Frame } from "../components/primitives";
import { Squiggle } from "../components/Doodles";

const SPAN = {
  tall: "sm:row-span-2 aspect-[3/4] sm:aspect-auto sm:min-h-[26rem]",
  wide: "sm:col-span-2 aspect-[16/10]",
  sq:   "aspect-square",
  full: "sm:col-span-3 aspect-[16/9] sm:aspect-[21/9]",
};

export default function Life() {
  return (
    <section className="shell py-24 sm:py-32">
      <SectionHead index="05" label={life.label} title={life.title} note={life.note} />

      <div className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-3 sm:gap-6">
        {life.photos.map((photo, i) => (
          <Reveal
            key={photo.src}
            delay={i * 0.07}
            className={`${SPAN[photo.span]} group`}
          >
            <figure
              style={{ rotate: `${photo.rotate}deg` }}
              className="h-full bg-paper p-2.5 shadow-card transition-transform duration-500 ease-out hover:!rotate-0 hover:scale-[1.02]"
            >
              <Frame
                src={photo.src}
                alt={photo.caption}
                label={photo.src.split("/").pop()}
                className="h-[calc(100%-1.9rem)] min-h-[10rem] w-full"
              />
              <figcaption className="pt-2 text-center font-mono text-[11px] text-ink40">
                {photo.caption}
              </figcaption>
            </figure>
          </Reveal>
        ))}
      </div>

      <Reveal delay={0.1}>
        <Squiggle aria-hidden className="mx-auto mt-14 h-5 w-40 text-ink40/60" />
      </Reveal>
    </section>
  );
}
