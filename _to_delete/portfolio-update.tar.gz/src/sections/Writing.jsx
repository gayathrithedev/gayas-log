import { writing } from "../data/content";
import { Reveal, SectionHead } from "../components/primitives";

export default function Writing() {
  return (
    <section className="relative border-t border-rule">
      <div className="shell relative py-24 sm:py-32">
        <SectionHead id="writing" index="04" label="Writing" title="Notes & writing" note="thinking out loud" />

        <ul className="mt-12">
          {writing.map((post, i) => (
            <li key={post.title}>
              <Reveal delay={i * 0.06}>
                <a
                  href={post.href}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="group grid items-baseline gap-2 border-b border-rule py-7 transition-colors hover:border-ink/30 sm:grid-cols-[minmax(0,1fr)_auto] sm:gap-8"
                >
                  <div className="flex items-baseline gap-4">
                    <span className="font-mono text-[11px] text-ink40">{String(i + 1).padStart(2, "0")}</span>
                    <h3 className="font-display text-2xl leading-snug tracking-[-0.01em] transition-colors group-hover:text-ink70 sm:text-3xl">
                      {post.title}
                    </h3>
                  </div>
                  <div className="flex items-center gap-4 pl-8 font-mono text-[11px] uppercase tracking-[0.16em] text-ink40 sm:pl-0">
                    <span>{post.where}</span>
                    <span aria-hidden>·</span>
                    <span>{post.date}</span>
                    <span aria-hidden className="transition-transform duration-300 group-hover:translate-x-1 group-hover:text-ink">↗</span>
                  </div>
                </a>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
