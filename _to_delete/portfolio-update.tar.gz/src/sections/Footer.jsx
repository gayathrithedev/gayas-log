import { useEffect, useState } from "react";
import { profile, socials } from "../data/content";
import { Reveal } from "../components/primitives";

export default function Footer() {
  const [time, setTime] = useState("");

  useEffect(() => {
    const tick = () =>
      setTime(
        new Intl.DateTimeFormat("en-IN", {
          hour: "2-digit",
          minute: "2-digit",
          timeZone: "Asia/Kolkata",
          hour12: false,
        }).format(new Date())
      );
    tick();
    const id = setInterval(tick, 30_000);
    return () => clearInterval(id);
  }, []);

  return (
    <footer id="contact" className="border-t border-rule bg-paper">
      <div className="shell py-24 sm:py-32">
        <Reveal>
          <p className="eyebrow"><span className="text-ink40/70">06 — </span>Contact</p>
        </Reveal>

        <Reveal delay={0.06}>
          <h2 className="mt-6 max-w-[14ch] font-display text-[clamp(2.75rem,8vw,7rem)] leading-[0.92] tracking-[-0.03em]">
            Got something worth <span className="italic">building</span>?
          </h2>
        </Reveal>

        <Reveal delay={0.12}>
          <a
            href={`mailto:${profile.email}`}
            className="link-swipe mt-10 inline-block font-display text-2xl sm:text-3xl"
          >
            {profile.email}
          </a>
        </Reveal>

        <Reveal delay={0.18}>
          <ul className="mt-14 grid gap-x-10 gap-y-3 border-t border-rule pt-8 sm:grid-cols-2 lg:grid-cols-4">
            {socials.map((s) => (
              <li key={s.label}>
                <a
                  href={s.href}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="group flex items-baseline justify-between gap-4 border-b border-rule py-3 transition-colors hover:border-ink"
                >
                  <span className="text-lg">{s.label}</span>
                  <span className="font-mono text-[11px] text-ink40 transition-colors group-hover:text-ink">
                    {s.handle} ↗
                  </span>
                </a>
              </li>
            ))}
          </ul>
        </Reveal>

        <div className="mt-16 flex flex-wrap items-center justify-between gap-4 font-mono text-[11px] uppercase tracking-[0.16em] text-ink40">
          <span>
            {profile.location} · <span className="tabular-nums text-ink70">{time}</span> IST
          </span>
          <span>© {new Date().getFullYear()} {profile.name}</span>
          <span>built with react, vite &amp; too much coffee</span>
        </div>
      </div>
    </footer>
  );
}
