import { about, profile } from "../data/content";
import { Reveal, SectionHead, Sticker, Frame } from "../components/primitives";
import { Arrow } from "../components/Doodles";

export default function About() {
  return (
    <section className="shell py-24 sm:py-32">
      <SectionHead id="about" index="01" label={about.label} title={about.title} note="a little context" />

      <div className="mt-12 grid gap-12 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)] lg:gap-20">
        <div>
          {about.paragraphs.map((p, i) => (
            <Reveal key={i} delay={i * 0.08}>
              <p
                className={`text-pretty leading-[1.7] text-ink70 ${
                  i === 0 ? "text-xl sm:text-[22px] text-ink" : "mt-6 text-[17px]"
                }`}
              >
                {p}
              </p>
            </Reveal>
          ))}

          <Reveal delay={0.24}>
            <div className="mt-10 flex flex-wrap gap-2.5">
              {about.facts.map((f, i) => (
                <Sticker key={f} rotate={i % 2 ? 1.5 : -1.5} tone="paper2">
                  {f}
                </Sticker>
              ))}
            </div>
          </Reveal>
        </div>

        {/* portrait, taped to the page */}
        <Reveal delay={0.12} className="relative">
          <div className="relative mx-auto max-w-sm rotate-[1.5deg] bg-paper p-3 shadow-card">
            <span className="tape -top-3 left-1/2 -translate-x-1/2" aria-hidden />
            <Frame
              src={profile.portrait}
              alt={`${profile.name}, portrait`}
              label="portrait.jpg"
              className="aspect-[4/5] w-full"
            />
            <p className="mt-3 text-center font-mono text-[11px] text-ink40">{profile.portraitCaption}</p>
          </div>
          <Arrow aria-hidden className="absolute -bottom-4 -left-2 hidden h-14 w-20 text-ink40/60 lg:block" />
        </Reveal>
      </div>
    </section>
  );
}
