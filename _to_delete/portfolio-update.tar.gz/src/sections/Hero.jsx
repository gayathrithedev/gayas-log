import { useEffect, useState } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "motion/react";
import { profile, marquee } from "../data/content";
import { Button, Sticker } from "../components/primitives";
import { Mug, Braces, Atom, Sticky, Cursor, Spark, Squiggle } from "../components/Doodles";

/* Floating objects: position, size, tint, drift speed. */
const OBJECTS = [
  { C: Braces, cls: "left-[2.5%] top-[26%] h-12 w-12 text-ink70",     r: -8,  d: 0,   depth: 34 },
  { C: Mug,    cls: "right-[2.5%] top-[15%] h-14 w-14 text-ink40",    r: 10,  d: 0.6, depth: -26 },
  { C: Atom,   cls: "right-[3%] bottom-[26%] h-16 w-16 text-ink70",   r: -6,  d: 1.2, depth: 44 },
  { C: Sticky, cls: "left-[2%] bottom-[20%] h-12 w-12 text-ink40",    r: 7,   d: 0.9, depth: -18 },
  { C: Cursor, cls: "left-[44%] top-[7%] h-9 w-9 text-ink40",         r: -14, d: 1.6, depth: 22 },
  { C: Spark,  cls: "right-[16%] top-[44%] h-8 w-8 text-ink40",       r: 4,   d: 2.1, depth: -30 },
];

export default function Hero() {
  const reduce = useReducedMotion();
  const { scrollY } = useScroll();
  const [pointer, setPointer] = useState({ x: 0, y: 0 });

  const yHead = useTransform(scrollY, [0, 700], [0, reduce ? 0 : -60]);
  const oHead = useTransform(scrollY, [0, 520], [1, reduce ? 1 : 0.15]);

  useEffect(() => {
    if (reduce || window.matchMedia("(pointer: coarse)").matches) return;
    const onMove = (e) => {
      setPointer({
        x: e.clientX / window.innerWidth - 0.5,
        y: e.clientY / window.innerHeight - 0.5,
      });
    };
    window.addEventListener("pointermove", onMove);
    return () => window.removeEventListener("pointermove", onMove);
  }, [reduce]);

  return (
    <section id="top" className="relative overflow-hidden pt-32 sm:pt-40 lg:pt-44">
      {/* warm wash behind the type */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-[70vh]"
        style={{
          background:
            "radial-gradient(60% 46% at 50% 14%, rgba(16,16,16,.045), transparent 72%)",
        }}
      />

      {/* floating objects */}
      <div aria-hidden className="pointer-events-none absolute inset-0 hidden xl:block">
        {OBJECTS.map(({ C, cls, r, d, depth }, i) => (
          <motion.div
            key={i}
            className={`absolute ${cls} animate-floaty opacity-45`}
            style={{ "--r": `${r}deg`, animationDelay: `${d}s` }}
            animate={{ x: pointer.x * depth, y: pointer.y * depth }}
            transition={{ type: "spring", stiffness: 40, damping: 18, mass: 1.2 }}
          >
            <C className="h-full w-full" />
          </motion.div>
        ))}
      </div>

      <motion.div style={{ y: yHead, opacity: oHead }} className="shell relative">
        {/* greeting */}
        <motion.div
          initial={reduce ? false : { opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="flex flex-wrap items-center gap-3"
        >
          <span className="greeting text-3xl leading-none sm:text-4xl">{profile.greeting}</span>
          <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-ink40">
            {profile.greetingRoman} — hello
          </span>
          {profile.available && (
            <Sticker tone="paper2" rotate={-2} className="ml-1">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-ink40 opacity-60" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-ink" />
              </span>
              {profile.availableNote}
            </Sticker>
          )}
        </motion.div>

        {/* headline */}
        <h1 className="mt-7 max-w-[16ch] font-display text-[clamp(3rem,9.2vw,8.5rem)] leading-[0.9] tracking-[-0.03em] text-balance">
          {profile.headline.map((chunk, i) => (
            <motion.span
              key={i}
              initial={reduce ? false : { opacity: 0, y: 26, filter: "blur(6px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              transition={{ duration: 0.85, delay: 0.12 + i * 0.12, ease: [0.22, 1, 0.36, 1] }}
              className={chunk.em ? "italic" : ""}
            >
              {chunk.text}
            </motion.span>
          ))}
          <motion.span
            aria-hidden
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9 }}
            className="ml-2 inline-block h-[0.72em] w-[0.055em] translate-y-[0.02em] animate-blink bg-ink align-baseline"
          />
        </h1>

        {/* meta row + blurb */}
        <motion.div
          initial={reduce ? false : { opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="mt-10 grid gap-8 border-t border-rule pt-8 md:grid-cols-[minmax(0,1fr)_minmax(0,1.15fr)] md:gap-14"
        >
          <div>
            <p className="font-display text-2xl leading-tight">{profile.name}</p>
            <p className="mt-1 font-mono text-[12px] uppercase tracking-[0.16em] text-ink40">
              {profile.role} · {profile.location}
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <Button href="#work">See the work</Button>
              <Button href={`mailto:${profile.email}`} tone="ghost">Get in touch</Button>
            </div>
          </div>

          <div className="relative">
            <Squiggle aria-hidden className="absolute -top-6 left-0 hidden h-4 w-28 text-ink40/70 md:block" />
            <p className="text-pretty text-[17px] leading-[1.65] text-ink70 sm:text-lg">
              {profile.blurb}
            </p>
          </div>
        </motion.div>
      </motion.div>

      {/* marquee */}
      <div className="relative mt-16 border-y border-rule bg-paper py-3 sm:mt-24">
        <div className="mask-fade-x flex overflow-hidden">
          <div className="flex shrink-0 animate-marquee items-center gap-8 pr-8">
            {[...marquee, ...marquee].map((word, i) => (
              <span key={i} className="flex shrink-0 items-center gap-8 font-mono text-[12px] uppercase tracking-[0.18em] text-ink40">
                {word}
                <span className="text-ink40/60" aria-hidden>/</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
