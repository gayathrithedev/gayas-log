import { useRef } from "react";
import { motion, useReducedMotion } from "motion/react";
import { projects } from "../data/content";
import { Reveal, SectionHead, Frame } from "../components/primitives";

const ACCENT = {
  flame: { text: "text-ink70", bg: "bg-paper2", border: "hover:border-ink/30" },
  moss:  { text: "text-ink70", bg: "bg-paper2", border: "hover:border-ink/30" },
  ochre: { text: "text-ink70", bg: "bg-paper2", border: "hover:border-ink/30" },
};

function Card({ p, i }) {
  const reduce = useReducedMotion();
  const ref = useRef(null);
  const a = ACCENT[p.accent] ?? ACCENT.flame;
  const flip = i % 2 === 1;

  // subtle tilt toward the cursor
  const onMove = (e) => {
    if (reduce || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    ref.current.style.transform = `perspective(1100px) rotateX(${-py * 3}deg) rotateY(${px * 4}deg) translateY(-4px)`;
  };
  const onLeave = () => {
    if (ref.current) ref.current.style.transform = "";
  };

  return (
    <Reveal delay={0.05}>
      <motion.article
        ref={ref}
        onPointerMove={onMove}
        onPointerLeave={onLeave}
        className={`group grid items-center gap-8 rounded-[26px] border border-rule bg-paper p-5 shadow-card transition-[transform,border-color,box-shadow] duration-500 ease-out hover:shadow-lift sm:p-7 lg:grid-cols-2 lg:gap-12 lg:p-8 ${a.border}`}
      >
        {/* visual */}
        <div className={`relative ${flip ? "lg:order-2" : ""}`}>
          <div className={`absolute -inset-2 rounded-[22px] ${a.bg} opacity-0 transition-opacity duration-500 group-hover:opacity-100`} aria-hidden />
          <Frame
            src={p.image}
            alt={`${p.title} preview`}
            label={`${p.title}.png`}
            className="relative aspect-[16/11] w-full rounded-[18px] border border-rule"
          />
          <span className={`absolute -left-3 -top-3 grid h-11 w-11 place-items-center rounded-full border border-rule bg-paper font-mono text-xs ${a.text} shadow-sticker`}>
            {p.n}
          </span>
        </div>

        {/* copy */}
        <div className={flip ? "lg:order-1" : ""}>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <span className={`font-mono text-[11px] uppercase tracking-[0.18em] ${a.text}`}>{p.kind}</span>
            <span className="text-ink40" aria-hidden>·</span>
            <span className="font-mono text-[11px] tracking-tight text-ink40">{p.year}</span>
          </div>

          <h3 className="mt-3 font-display text-4xl leading-[1.02] tracking-[-0.02em] sm:text-5xl">
            <a href={p.href} target="_blank" rel="noreferrer noopener" className="link-swipe">
              {p.title}
            </a>
          </h3>

          <p className="mt-4 text-pretty leading-[1.7] text-ink70">{p.summary}</p>

          <dl className="mt-6 flex flex-wrap items-baseline gap-x-2 border-t border-rule pt-4 font-mono text-[11px] uppercase tracking-[0.14em] text-ink40">
            <dt className="sr-only">Role</dt>
            <dd className="text-ink70">{p.contribution}</dd>
          </dl>

          <ul className="mt-4 flex flex-wrap gap-2">
            {p.stack.map((t) => (
              <li key={t} className="rounded-full border border-rule px-2.5 py-1 font-mono text-[11px] text-ink70">
                {t}
              </li>
            ))}
          </ul>

          <a
            href={p.href}
            target="_blank"
            rel="noreferrer noopener"
            className="mt-7 inline-flex items-center gap-2 text-sm font-medium text-ink transition-colors hover:text-ink70"
          >
            View project
            <span aria-hidden className="transition-transform duration-300 group-hover:translate-x-1">→</span>
          </a>
        </div>
      </motion.article>
    </Reveal>
  );
}

export default function Work() {
  return (
    <section className="relative border-t border-rule">
      <div className="shell relative py-24 sm:py-32">
        <SectionHead id="work" index="02" label="Work" title="Selected work" note="things that shipped" />
        <div className="mt-14 grid gap-8 sm:gap-10">
          {projects.map((p, i) => (
            <Card key={p.title} p={p} i={i} />
          ))}
        </div>

        <Reveal delay={0.1}>
          <p className="mt-12 text-center font-mono text-[12px] text-ink40">
            more in the wild →{" "}
            <a href="https://github.com/gayathrithedev?tab=repositories" target="_blank" rel="noreferrer noopener" className="link-swipe text-ink70">
              github.com/gayathrithedev
            </a>
          </p>
        </Reveal>
      </div>
    </section>
  );
}
