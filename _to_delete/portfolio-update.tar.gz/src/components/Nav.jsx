import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { nav, profile } from "../data/content";

export default function Nav() {
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
  }, [open]);

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[80] focus:rounded-full focus:bg-ink focus:px-4 focus:py-2 focus:text-sm focus:text-paper"
      >
        Skip to content
      </a>

      <header className="fixed inset-x-0 top-0 z-50">
        <div
          className={`transition-all duration-500 ${
            solid ? "bg-paper/85 backdrop-blur-md" : "bg-transparent"
          }`}
        >
          <div className={`shell flex items-center justify-between transition-all duration-500 ${solid ? "py-3" : "py-5"}`}>
            <a href="#top" className="group flex items-baseline gap-2">
              <span className="font-display text-[22px] leading-none tracking-[-0.01em]">
                Gayathri Perumal
              </span>
              <span
                aria-hidden
                className="hidden h-1.5 w-1.5 rounded-full bg-ink40 transition-colors group-hover:bg-ink sm:block"
              />
            </a>

            <nav className="hidden items-center gap-1 md:flex" aria-label="Sections">
              {nav.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="rounded-full px-3.5 py-1.5 text-sm text-ink70 transition-colors hover:bg-paper2 hover:text-ink"
                >
                  {item.label}
                </a>
              ))}
              <a
                href={`mailto:${profile.email}`}
                className="ml-2 rounded-full bg-ink px-4 py-1.5 text-sm text-paper transition-colors hover:bg-ink70"
              >
                Say hello
              </a>
            </nav>

            <button
              onClick={() => setOpen(true)}
              className="rounded-full border border-ink/20 px-4 py-1.5 text-sm md:hidden"
              aria-label="Open menu"
            >
              Menu
            </button>
          </div>
          <div className={`h-px w-full bg-rule transition-opacity duration-500 ${solid ? "opacity-100" : "opacity-0"}`} />
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed inset-0 z-[70] bg-paper md:hidden"
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="shell flex items-center justify-between py-5">
              <span className="font-display text-[22px]">Gayathri Perumal</span>
              <button onClick={() => setOpen(false)} className="rounded-full border border-ink/20 px-4 py-1.5 text-sm">
                Close
              </button>
            </div>
            <nav className="shell mt-6 flex flex-col" aria-label="Sections">
              {[...nav, { label: "Say hello", href: `mailto:${profile.email}` }].map((item, i) => (
                <motion.a
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  initial={{ opacity: 0, x: -14 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 + i * 0.05 }}
                  className="border-b border-rule py-5 font-display text-4xl"
                >
                  {item.label}
                </motion.a>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
