import { profile, socials, contactLinks } from "../data/content";

const ICONS = { mail: MailIcon, linkedin: LinkedInIcon, x: XIcon };
import { Reveal } from "../components/primitives";
import FlowerPatch from "../components/FlowerPatch";
import { MailIcon, LinkedInIcon, XIcon } from "../components/SocialIcons";

export default function Footer() {
  return (
    <footer id="contact" className="border-t border-rule bg-paper">
      <div className="shell py-16 sm:py-20">
        <Reveal>
          <p className="eyebrow"><span className="text-ink40/70">04 — </span>Contact</p>
        </Reveal>

        <Reveal delay={0.06}>
          <h2 className="mt-4 font-display text-[32px] leading-[1.1] tracking-[-0.02em] sm:text-[38px]">
            Got something worth <span className="italic">building</span>?
          </h2>
        </Reveal>

        <Reveal delay={0.12}>
          <a
            href={`mailto:${profile.email}`}
            className="link-swipe mt-6 inline-block font-display text-[22px]"
          >
            {profile.email}
          </a>
        </Reveal>

        <Reveal delay={0.18}>
          <ul className="mt-10 grid gap-x-8 gap-y-1 border-t border-rule pt-6 sm:grid-cols-2">
            {socials.map((s) => (
              <li key={s.label}>
                <a
                  href={s.href}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="group flex items-baseline justify-between gap-4 border-b border-rule py-2.5 transition-colors hover:border-ink"
                >
                  <span className="text-[15px]">{s.label}</span>
                  <span className="font-mono text-[11px] text-ink40 transition-colors group-hover:text-ink">
                    {s.handle} ↗
                  </span>
                </a>
              </li>
            ))}
          </ul>
        </Reveal>

        {/* the meadow */}
        <Reveal delay={0.24}>
          <div className="mt-20 flex flex-col items-center">
            <FlowerPatch className="h-[112px] w-[140px]" />

            <p className="mt-3 text-[15px] text-ink70">
              Crafted with claude &amp; chaos at 3am :)
            </p>

            <ul className="mt-5 flex items-center gap-2.5">
              {contactLinks.map(({ icon, label, href }) => {
                const Icon = ICONS[icon];
                const external = href.startsWith("http");
                return (
                  <li key={label}>
                    <a
                      href={href}
                      aria-label={label}
                      title={label}
                      {...(external ? { target: "_blank", rel: "noreferrer noopener" } : {})}
                      className="grid h-10 w-10 place-items-center rounded-[10px] bg-paper2 text-ink70 transition-colors duration-300 hover:bg-ink hover:text-paper"
                    >
                      <Icon className="h-[18px] w-[18px]" />
                    </a>
                  </li>
                );
              })}
            </ul>
          </div>
        </Reveal>

        <div className="mt-14 flex flex-col gap-1.5 font-mono text-[10px] uppercase tracking-[0.16em] text-ink40 sm:flex-row sm:items-center sm:justify-between">
          <span>{profile.location}</span>
          <span>© {new Date().getFullYear()} {profile.name}</span>
        </div>
      </div>
    </footer>
  );
}
