import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { HazelSitting, HazelSleeping } from "./Hazel";

/* A little meadow. Hovering grows five more flowers in colour, then
   Hazel wanders in, blinks, purrs, and curls up next to them. */

const PETALS = 11;

function Daisy({ cx, cy, r, rot = 0, color }) {
  return (
    <g stroke={color} fill="none" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round">
      {Array.from({ length: PETALS }, (_, i) => {
        const a = (360 / PETALS) * i + rot;
        return (
          <ellipse
            key={i}
            cx={cx}
            cy={cy - r * 0.62}
            rx={r * 0.19}
            ry={r * 0.42}
            transform={`rotate(${a} ${cx} ${cy})`}
          />
        );
      })}
      <circle cx={cx} cy={cy} r={r * 0.2} />
    </g>
  );
}

function Stem({ x, yTop, yBase, sway = 4, color }) {
  const h = yBase - yTop;
  const d = `M ${x} ${yBase}
             C ${x - sway} ${yBase - h * 0.3}, ${x + sway} ${yBase - h * 0.5}, ${x - sway * 0.4} ${yBase - h * 0.72}
             S ${x} ${yTop + 2}, ${x} ${yTop}`;
  return <path d={d} stroke={color} fill="none" strokeWidth="1" strokeLinecap="round" />;
}

function Flower({ x, top, base, r, rot, sway, color }) {
  return (
    <>
      <Stem x={x} yTop={top + r * 0.9} yBase={base} sway={sway} color={color} />
      <Daisy cx={x} cy={top} r={r} rot={rot} color={color} />
    </>
  );
}

const INK = "#4E4E4B";
const BLUE = "#1D4ED8";
const YELLOW = "#E0A400";
const PINK = "#E0479B";

const BASE = [
  { x: 30, top: 60, base: 118, r: 11, rot: 6, sway: 4 },
  { x: 62, top: 34, base: 120, r: 16, rot: 14, sway: 5 },
  { x: 100, top: 42, base: 118, r: 14, rot: 3, sway: 4 },
  { x: 132, top: 66, base: 122, r: 12, rot: 20, sway: 3 },
];

const EXTRA = [
  { x: 14, top: 74, base: 120, r: 9, rot: 10, sway: 3, color: BLUE, delay: 0 },
  { x: 46, top: 84, base: 121, r: 8, rot: 24, sway: 3, color: PINK, delay: 0.12 },
  { x: 80, top: 70, base: 119, r: 10, rot: 2, sway: 4, color: YELLOW, delay: 0.06 },
  { x: 114, top: 88, base: 120, r: 8, rot: 16, sway: 3, color: BLUE, delay: 0.24 },
  { x: 148, top: 78, base: 121, r: 9, rot: 8, sway: 4, color: PINK, delay: 0.18 },
];

/* The sequence, in milliseconds after hover begins. */
const CUES = [
  { stage: "walk", at: 900 },
  { stage: "sit", at: 1750 },
  { stage: "purr", at: 2600 },
  { stage: "sleep", at: 4200 },
];

const EASE = [0.22, 1, 0.36, 1];

export default function FlowerPatch({ className = "" }) {
  const reduce = useReducedMotion();
  const [hover, setHover] = useState(false);
  const [stage, setStage] = useState("idle"); // idle | walk | sit | purr | sleep
  const [blink, setBlink] = useState(false);
  const timers = useRef([]);

  const clear = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  };

  // drop any pending cues if the component goes away mid-sequence
  useEffect(() => clear, []);

  const start = () => {
    clear();
    setHover(true);
    if (reduce) {
      setStage("sleep");
      return;
    }
    CUES.forEach(({ stage: cue, at }) => {
      timers.current.push(setTimeout(() => setStage(cue), at));
    });
    // two blinks shortly after she settles
    [2000, 2180, 2420, 2600].forEach((t, i) => {
      timers.current.push(setTimeout(() => setBlink(i % 2 === 0), t));
    });
  };

  const stop = () => {
    clear();
    setHover(false);
    setStage("idle");
    setBlink(false);
  };

  const bloomed = hover;
  const catOut = stage !== "idle";
  const asleep = stage === "sleep";

  return (
    <div
      className={`relative ${className}`}
      onPointerEnter={start}
      onPointerLeave={stop}
    >
      <svg viewBox="0 0 162 130" role="img" aria-label="A small patch of daisies" className="h-full w-full overflow-visible">
        {BASE.map((f, i) => (
          <Flower key={`b${i}`} {...f} color={INK} />
        ))}

        {EXTRA.map((f, i) => (
          <motion.g
            key={`e${i}`}
            style={{ transformBox: "view-box", transformOrigin: `${f.x}px ${f.base}px` }}
            initial={false}
            animate={bloomed ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.4 }}
            transition={{
              duration: reduce ? 0 : 0.75,
              delay: bloomed && !reduce ? f.delay : 0,
              ease: EASE,
            }}
          >
            <Flower {...f} />
          </motion.g>
        ))}
      </svg>

      {/* Hazel, walking in from the right and settling by the flowers */}
      <AnimatePresence>
        {catOut && (
          <motion.div
            className="pointer-events-none absolute bottom-[-6px] right-[-40px]"
            initial={{ opacity: 0, x: 46 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 40, transition: { duration: 0.35 } }}
            transition={{ duration: 0.85, ease: EASE }}
          >
            <AnimatePresence mode="wait">
              {asleep ? (
                <motion.div
                  key="sleep"
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.45, ease: EASE }}
                  className="relative"
                >
                  {/* slow breathing */}
                  <motion.div
                    animate={{ scaleY: [1, 1.035, 1] }}
                    transition={{ duration: 2.6, repeat: Infinity, ease: "easeInOut" }}
                    style={{ transformOrigin: "bottom center" }}
                  >
                    <HazelSleeping className="h-[38px] w-[70px]" />
                  </motion.div>
                  <Zzz />
                </motion.div>
              ) : (
                <motion.div
                  key="up"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="relative"
                >
                  <motion.div
                    /* a little bob while she pads in, then still */
                    animate={stage === "walk" ? { y: [0, -2.5, 0] } : { y: 0 }}
                    transition={
                      stage === "walk"
                        ? { duration: 0.42, repeat: Infinity, ease: "easeInOut" }
                        : { duration: 0.3 }
                    }
                  >
                    <HazelSitting blink={blink} className="h-[58px] w-[52px]" />
                  </motion.div>
                  {stage === "purr" && <Purr />}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* Three little arcs pulsing out — the visual of a purr. */
function Purr() {
  return (
    <svg viewBox="0 0 24 30" className="absolute -right-4 top-1 h-[26px] w-[20px]" aria-hidden>
      {[0, 1, 2].map((i) => (
        <motion.path
          key={i}
          d={`M4 ${15} q ${5 + i * 4} -${5 + i * 3.5} 0 -${10 + i * 7}`}
          fill="none"
          stroke="#C56E23"
          strokeWidth="1.4"
          strokeLinecap="round"
          initial={{ opacity: 0, scale: 0.7 }}
          animate={{ opacity: [0, 0.85, 0], scale: [0.7, 1, 1.12] }}
          transition={{ duration: 1.4, repeat: Infinity, delay: i * 0.22, ease: "easeOut" }}
          style={{ transformBox: "fill-box", transformOrigin: "bottom left" }}
        />
      ))}
    </svg>
  );
}

/* Sleepy z's drifting up. */
function Zzz() {
  return (
    <div aria-hidden className="absolute -top-1 right-2 select-none">
      {[0, 1, 2].map((i) => (
        <motion.span
          key={i}
          className="absolute font-mono text-ink40"
          style={{ fontSize: 9 + i * 2, right: i * 9, bottom: i * 4 }}
          animate={{ opacity: [0, 0.9, 0], y: [4, -12, -20] }}
          transition={{ duration: 2.6, repeat: Infinity, delay: i * 0.6, ease: "easeOut" }}
        >
          z
        </motion.span>
      ))}
    </div>
  );
}
