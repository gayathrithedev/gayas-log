import { motion } from "motion/react";
import { about, skills, contactLinks } from "../data/content";
import { Reveal } from "../components/primitives";
import { MailIcon, LinkedInIcon, XIcon } from "../components/SocialIcons";

const ICONS = { mail: MailIcon, linkedin: LinkedInIcon, x: XIcon };

/* Chips slide in from the right, trailing each other. */
const reduceSafe = {
  rest: { opacity: 0, x: 28 },
  go: { opacity: 1, x: 0, transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] } },
};

export default function About() {
  return (
    <section id="about" className="shell scroll-mt-24 pb-16 pt-5 sm:pb-20">
      <div>
        {about.paragraphs.map((p, i) => (
          <Reveal key={i} delay={i * 0.06}>
            <p className={`text-pretty text-[17px] leading-[1.7] text-ink70 ${i ? "mt-5" : ""}`}>
              {p}
            </p>
          </Reveal>
        ))}
      </div>

      <Reveal delay={0.2}>
        <ul className="mt-8 flex flex-wrap items-center gap-2.5">
          {contactLinks.map(({ icon, label, href }) => {
            const Icon = ICONS[icon];
            const external = href.startsWith("http");
            return (
              <li key={label}>
                <a
                  href={href}
                  aria-label={label}
                  title={label}
                  {...(external ? { target: "_blank", rel: "noreferrer noopener" } : {})}
                  className="grid h-10 w-10 place-items-center rounded-[10px] bg-paper2 text-ink70 transition-colors duration-300 hover:bg-ink hover:text-paper"
                >
                  <Icon className="h-[18px] w-[18px]" />
                </a>
              </li>
            );
          })}
        </ul>
      </Reveal>

      <Reveal delay={0.24}>
        <div className="mt-10 border-t border-rule pt-5">
          <p className="eyebrow">Tools of the trade</p>

          {/* each chip pulls in behind the one before it, like carriages */}
          <motion.ul
            className="mt-4 flex flex-wrap gap-2"
            initial="rest"
            whileInView="go"
            viewport={{ once: true, margin: "-10% 0px" }}
            variants={{ go: { transition: { staggerChildren: 0.055 } } }}
          >
            {skills.map((skill) => (
              <motion.li
                key={skill}
                variants={{
                  rest: reduceSafe.rest,
                  go: reduceSafe.go,
                }}
                className="rounded-full border border-rule bg-paper px-3 py-1.5 font-mono text-[12px] text-ink70"
              >
                {skill}
              </motion.li>
            ))}
          </motion.ul>
        </div>
      </Reveal>
    </section>
  );
}
