/* Hazel — a ginger tabby, in two poses.
   Both face left and share a palette so they cross-fade cleanly. */

export const GINGER = "#EFB472";      // her base coat — cream-apricot, not deep orange
export const GINGER_DARK = "#D2803C";  // tabby stripes
export const CREAM = "#FCF7EF";        // bib, chin, socks
export const OUTLINE = "#A9713A";
export const NOSE = "#E89AA4";
export const EYE = "#D4A017";          // amber, not green
export const COLLAR = "#E9A6BD";       // her pink collar

/* Sitting upright, tail curled around the front paws. */
export function HazelSitting({ blink = false, ...rest }) {
  return (
    <svg viewBox="0 0 80 90" {...rest}>
      {/* tail, sweeping round the front */}
      <path
        d="M56 78 C 70 78, 72 62, 62 58 C 56 55.5, 52 60, 55 64"
        fill="none"
        stroke={GINGER}
        strokeWidth="7"
        strokeLinecap="round"
      />
      <path
        d="M56 78 C 70 78, 72 62, 62 58 C 56 55.5, 52 60, 55 64"
        fill="none"
        stroke={OUTLINE}
        strokeWidth="1.1"
        strokeLinecap="round"
        opacity=".45"
      />

      {/* haunch + body */}
      <path
        d="M26 80 C 20 80, 17 68, 20 55 C 23 42, 31 36, 40 36 C 49 36, 57 42, 60 55 C 63 68, 60 80, 54 80 Z"
        fill={GINGER}
        stroke={OUTLINE}
        strokeWidth="1.3"
        strokeLinejoin="round"
      />
      {/* chest */}
      <path d="M31 79 C 28 66, 31 53, 40 49 C 49 53, 52 66, 49 79 Z" fill={CREAM} />
      {/* body stripes */}
      <g stroke={GINGER_DARK} strokeWidth="2.4" strokeLinecap="round" opacity=".55" fill="none">
        <path d="M22 52 h7" />
        <path d="M21 60 h6" />
        <path d="M58 52 h-7" />
        <path d="M59 60 h-6" />
      </g>

      {/* ears */}
      <path d="M25 24 L23 9 L36 17 Z" fill={GINGER} stroke={OUTLINE} strokeWidth="1.3" strokeLinejoin="round" />
      <path d="M55 24 L57 9 L44 17 Z" fill={GINGER} stroke={OUTLINE} strokeWidth="1.3" strokeLinejoin="round" />
      <path d="M27.2 21.5 L26 13.5 L33 18 Z" fill={NOSE} opacity=".75" />
      <path d="M52.8 21.5 L54 13.5 L47 18 Z" fill={NOSE} opacity=".75" />

      {/* head */}
      <ellipse cx="40" cy="27" rx="18" ry="15.5" fill={GINGER} stroke={OUTLINE} strokeWidth="1.3" />
      {/* forehead stripes */}
      <g stroke={GINGER_DARK} strokeWidth="1.6" strokeLinecap="round" opacity=".6" fill="none">
        <path d="M40 13.5 v4.5" />
        <path d="M34.5 14.5 l-1 4" />
        <path d="M45.5 14.5 l1 4" />
      </g>
      {/* muzzle */}
      <ellipse cx="40" cy="33.5" rx="10.5" ry="6.5" fill={CREAM} />

      {/* eyes */}
      {blink ? (
        <g stroke={OUTLINE} strokeWidth="1.7" strokeLinecap="round" fill="none">
          <path d="M29.5 26.5 q3.5 3 7 0" />
          <path d="M43.5 26.5 q3.5 3 7 0" />
        </g>
      ) : (
        <>
          <ellipse cx="33" cy="26" rx="4" ry="4.6" fill={EYE} />
          <ellipse cx="47" cy="26" rx="4" ry="4.6" fill={EYE} />
          <ellipse cx="33" cy="26.2" rx="1.3" ry="3.6" fill="#22201C" />
          <ellipse cx="47" cy="26.2" rx="1.3" ry="3.6" fill="#22201C" />
          <circle cx="31.7" cy="24" r="1.1" fill="#fff" />
          <circle cx="45.7" cy="24" r="1.1" fill="#fff" />
        </>
      )}

      {/* nose + mouth */}
      <path d="M40 31.6 l-2-1.7 h4 Z" fill={NOSE} />
      <path d="M40 31.6 v1.7 M40 33.3 q-2.4 2 -4.2 .2 M40 33.3 q2.4 2 4.2 .2"
            stroke={OUTLINE} strokeWidth="1.1" strokeLinecap="round" fill="none" />
      {/* whiskers */}
      <g stroke={OUTLINE} strokeWidth=".9" strokeLinecap="round" opacity=".55" fill="none">
        <path d="M31 32 L18 30" />
        <path d="M31 34 L18.5 35.5" />
        <path d="M49 32 L62 30" />
        <path d="M49 34 L61.5 35.5" />
      </g>

      {/* her pink collar */}
      <path d="M28 45 q12 7 24 0" stroke={COLLAR} strokeWidth="3.2" fill="none" strokeLinecap="round" />
      <circle cx="40" cy="49.4" r="1.9" fill="#D8D3CA" stroke={OUTLINE} strokeWidth=".7" />

      {/* front paws */}
      <ellipse cx="34" cy="80" rx="6" ry="3.6" fill={CREAM} stroke={OUTLINE} strokeWidth="1.1" />
      <ellipse cx="46" cy="80" rx="6" ry="3.6" fill={CREAM} stroke={OUTLINE} strokeWidth="1.1" />
    </svg>
  );
}

/* Curled up asleep, nose tucked into the tail. */
export function HazelSleeping(props) {
  return (
    <svg viewBox="0 0 110 60" {...props}>
      {/* tail wrapped around the front */}
      <path
        d="M84 46 C 98 44, 100 30, 88 28 C 78 26.5, 72 34, 76 40"
        fill="none"
        stroke={GINGER}
        strokeWidth="7"
        strokeLinecap="round"
      />
      <path
        d="M84 46 C 98 44, 100 30, 88 28 C 78 26.5, 72 34, 76 40"
        fill="none"
        stroke={OUTLINE}
        strokeWidth="1"
        strokeLinecap="round"
        opacity=".4"
      />

      {/* curled body */}
      <path
        d="M14 46 C 8 30, 22 14, 44 14 C 68 14, 86 24, 86 38 C 86 44, 82 47, 74 47 Z"
        fill={GINGER}
        stroke={OUTLINE}
        strokeWidth="1.3"
        strokeLinejoin="round"
      />
      {/* back stripes */}
      <g stroke={GINGER_DARK} strokeWidth="2.6" strokeLinecap="round" opacity=".5" fill="none">
        <path d="M44 16 q3 5 1 9" />
        <path d="M56 17 q3 5 1 9" />
        <path d="M68 21 q3 4 1 8" />
      </g>

      {/* head, tucked down at the left */}
      <ellipse cx="26" cy="36" rx="15" ry="12.5" fill={GINGER} stroke={OUTLINE} strokeWidth="1.3" />
      <path d="M15 28 L12 17 L24 23 Z" fill={GINGER} stroke={OUTLINE} strokeWidth="1.2" strokeLinejoin="round" />
      <path d="M35 27 L40 17 L28 21 Z" fill={GINGER} stroke={OUTLINE} strokeWidth="1.2" strokeLinejoin="round" />
      <ellipse cx="24" cy="41" rx="9" ry="5.6" fill={CREAM} />

      {/* closed eyes */}
      <g stroke={OUTLINE} strokeWidth="1.6" strokeLinecap="round" fill="none">
        <path d="M17 35 q3 2.8 6 0" />
        <path d="M29 35 q3 2.8 6 0" />
      </g>
      <path d="M24 39.5 l-1.8-1.5 h3.6 Z" fill={NOSE} />
      <g stroke={OUTLINE} strokeWidth=".9" strokeLinecap="round" opacity=".5" fill="none">
        <path d="M16 40 L5 39" />
        <path d="M16 42 L5.5 44" />
      </g>
    </svg>
  );
}
